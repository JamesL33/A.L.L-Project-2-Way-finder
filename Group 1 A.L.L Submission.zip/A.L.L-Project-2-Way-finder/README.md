# A.L.L-Project-2-Way-finder TO DO LIST
A.L.L Project 2 creating a way-finder for Coventry University.

To use the website for localhost first of all you will need to open the website.conf file and change the root path to where you have the website files stored.
Next you must run the CherryPyWebsite.py and you should be able to connect to the navigation website using http://localhost:8080.

- Fix the error in the Main.js script meaning that when the user clicks of the menu it doesn't close when it should.

- Add pictures from http://www.coventry.ac.uk/life-on-campus/the-university/our-buildings/buildings/ to the sidebarImages folder
    - DO NOT grab the images from that page, the resolution is crap, so images will have to be gathered and cropped down to the correct determined size

- Finish messing around with text size and padding on the integratedPage html page.
    - Ensure the text looks good on a tablet or add auto fitting ratios instead of using 'em'.

- Add more/different coloured markers for each building location - Make them clickable(?)

- Add generic background info text for each building in the sidebar of the integratedPage html page.
